<?php
// コントローラはクラスとして作成される。
// 名前空間:クラスを階層的に整理するための仕組み。　フォルダを使って階層的にファイルを整理するみたいな感じ
namespace App\Http\Controllers;
// use文:　Illuminate\Http\パッケージ内に用意されている「Request」を使える状態にしている
use Illuminate\Http\Request;
use Illuminate\Http\Response;

// クラスの定義 Controllerというクラスを継承して作る
class HelloController extends Controller
{
  public function index(Request $request){
    return view('hello.index',['data'=>$request->data]);
  }

}
