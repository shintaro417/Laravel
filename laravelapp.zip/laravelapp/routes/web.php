<?php
use App\Http\Middleware\HelloMiddleware;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get(アドレス,関数など); getメソッドでアドレスと処理を割り当てる、ということがルート情報設定の基本
Route::get('/', function () {
    return view('welcome');
});

// ルート情報の用意:アクションを使うようにするためにはアクションにルートを割り当てる設定が必要
// コントローラを利用する場合は第二引数に「呼び出すコントローラとアクション」を指定する コントローラ@アクションという感じで繋ぐ 第一引数はアクセスするルート
// Route::get('hello/{id?}/{pass?}', 'HelloController@index');


Route::get('/hello', 'HelloController@index')->middleware(HelloMiddleware::class);
// Route::post('hello','HelloController@post');
