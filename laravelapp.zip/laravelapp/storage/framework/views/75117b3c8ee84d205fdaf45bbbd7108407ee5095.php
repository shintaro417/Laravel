<?php $__env->startSection('title', 'Index'); ?>

<?php $__env->startSection('menubar'); ?>
  ##parent-placeholder-b87313ea43ef51d84641be104c943962e1df3977##
  インデックスページ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <p>ここが本文のコンテンツです。</p>
  <p>Controller value<br>'message' = <?php echo e($message); ?></p>
  <p>ViewComposer value<br>'view_message' = <?php echo e($view_message); ?></p>
  </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2017 tuyano.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.helloapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravelapp/resources/views/hello/index.blade.php ENDPATH**/ ?>