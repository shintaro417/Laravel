<li><?php echo e($item['name']); ?> [<?php echo e($item['mail']); ?>]</li>
<?php /**PATH /Applications/MAMP/htdocs/laravelapp/resources/views/components/item.blade.php ENDPATH**/ ?>